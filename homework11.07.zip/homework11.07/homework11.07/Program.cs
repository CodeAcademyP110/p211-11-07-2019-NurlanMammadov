﻿using System;
using System.Text.RegularExpressions;

namespace homework11._07
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("how many groups do you want to add ?");
            int GroupCount = int.Parse(Console.ReadLine());

            Groups[] GroupArray = new Groups[GroupCount];

            for (int i = 0; i < GroupCount; i++)
            {
                GroupArray[i] = new Groups();

                Console.WriteLine($"Add to {i + 1}th group Name ");
                string gName = Console.ReadLine().ToLower();

                bool SameGroupName = false;
                for (int j = 0; j < GroupCount; j++)
                    foreach (var newGroup in GroupArray)
                    {
                        if (newGroup != null && (newGroup.GroupName == gName))
                        {
                            Console.WriteLine("Group name is duplicate. Please again input");
                            SameGroupName = true;
                            break;
                        }
                    }
                if ( SameGroupName == false)
                {
                    GroupArray[i].GroupName = gName;
                }
                else
                {
                    i--;
                }

            }



            Console.WriteLine("which group do you want to add students?");
            string StudentAddToGroup = Console.ReadLine();

            int SelectedGroupId = 0;
            string SelectedGroupName = "";
            bool FindGroup = false;
            for (int i = 0; i < GroupCount; i++)
            {
                if (StudentAddToGroup.ToLower() == GroupArray[i].GroupName)
                {

                    SelectedGroupId = GroupArray[i].Id;
                    SelectedGroupName = GroupArray[i].GroupName;
                    FindGroup = true;
                    break;
                }

            }

            if (FindGroup == false)
            {
                throw new ArgumentException("There is no Group With This ID");
            }

            //Create to Students

            Console.WriteLine("how many students do you want to add ?");
            int StudentCount = int.Parse(Console.ReadLine());

            Students[] StudentArray = new Students[StudentCount];

            for (int i = 0; i < StudentCount; i++)
            {
                StudentArray[i] = new Students();
                StudentArray[i].GroupId = SelectedGroupId;
                StudentArray[i].StudentGroupName = SelectedGroupName;
                GroupArray[i].GroupStudents = StudentArray[i].StudentName + StudentArray[i].StudentLastname;
                Console.WriteLine($"Add to {i + 1}th student Name ");
                string sName = Console.ReadLine().ToLower();


                Console.WriteLine($"Add to {i + 1}th student Lastname ");
                string sLastname = Console.ReadLine().ToLower();

                StudentArray[i].StudentLastname = sLastname;
                StudentArray[i].StudentName = sName;


            }



            Console.WriteLine("If do you want  groups press 1, students press 2");
            int searchPress = int.Parse(Console.ReadLine());
            bool HasGroup = false;
            if (searchPress == 1)
            {
                Console.WriteLine("please input your searching group ID");
                int SearchGroup = int.Parse(Console.ReadLine());

                for (int i = 0; i < GroupCount; i++)
                {
                    if (GroupArray[i].Id == SearchGroup)
                    {
                        Console.WriteLine(GroupArray[i].GroupName);
                        HasGroup = true;
                 
                    }
                }
                if (HasGroup == false)
                {
                    Console.WriteLine("Doesn't Find group with this ID");
                }
            }

            else if (searchPress == 2)
            {
                Console.WriteLine("please input your searching student ID");
                int SearchStudent = int.Parse(Console.ReadLine());
                bool HasStudent = false;

                for (int i = 0; i < StudentCount; i++)
                {
                    if (StudentArray[i].StudentId == SearchStudent)
                    {
                        Console.WriteLine($"Student's Name : {StudentArray[i].StudentName} \n" +
                            $" Student's Lastname : {StudentArray[i].StudentLastname} \n" +
                            $" Group Name : {StudentArray[i].StudentGroupName}");
                        HasStudent = true;
                    }

                }
                if (HasStudent == false)
                {

                    Console.WriteLine("doesn't find student with this ID");
                }
            }
            else
            {
                Console.WriteLine("please, input a valid number");
            }

            //bool hasGroup = false;
            //Console.WriteLine("Which group do you want to add Students?");
            //string StudentAddToGroup = Console.ReadLine();
            //for (int i = 0; i < GroupCount; i++)
            //{
            //    if (GroupArray[i].GroupName == StudentAddToGroup.ToLower())
            //    {
            //        hasGroup = true;

            //    }

            //}
            //if (hasGroup == false)
            //{
            //    Console.WriteLine("Doesn't exist your searching group");
            //}


            //for (int i = 0; i < StudentCount; i++)
            //{
            //    Console.WriteLine($" Student Name = {StudentArray[i].StudentName}   Student Id = {StudentArray[i].StudentId}");

            //}

        }
    }

    class Groups
    {

        static Groups()
        {
            _groupIdstart = 10;
        }

        public Groups()
        {
            Id = _groupIdstart++;
        }

        public int Id { get; set; }

        public static int _groupIdstart;

        public string GroupStudents { get; set; }

        private string _groupName;
        public string GroupName
        {
            get { return _groupName; }
            set
            {

                if ((value.Length < 4))
                {
                    throw new Exception("Please input Correct Group Name");
                }
                _groupName = value;
            }
        }
    }
    class Students
    {
        public int StudentId;
        public string StudentName { get; set; }
        public string StudentLastname { get; set; }

        public static int _studentId;
        public int GroupId { get; set; }

        public string StudentGroupName { get; set; }
        static Students()
        {
            _studentId = 1000;
        }
        public Students()
        {
            StudentId = _studentId++;
        }
    }
}
